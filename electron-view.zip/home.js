// 切换页面

document.getElementById('snowballPricing').addEventListener('click', () => {
    window.location.href = 'pricing.html';
});

document.getElementById('monteCarlo').addEventListener('click', () => {
    window.location.href = 'monte-carlo.html';
});

document.getElementById('snowballBacktest').addEventListener('click', () => {
    window.location.href = 'backtesting.html';
});
