```JavaScript
{
    "xvec": {
        "range": [                       // stock price
            75.8456,
            ... (additional values)
            274.3676,
            286.8926
        ],
        "index": null
    },
    "before": {                          // before mass transfer
        "KI": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ],
        "DNT": [
            0.0,
            ... (additional values)
            -0.0,
            0.0
        ],
        "KO": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ],
        "SNB": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ]
    },
    "after": {                           // after mass transfer
        "KI": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ],
        "DNT": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ],
        "KO": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ],
        "SNB": [
            0.0,
            ... (additional values)
            0.0,
            0.0
        ]
    },
    "parameter": {                       // input parameters
        "kiInput": 85.0,
        "koInput": 103.0,
        "Nx": 20
    },
    "price": {                           // price decomposition
        "KI": -1.605,
        "DNT": 2.6119,
        "KO": [
            0.4982,
            0.1623,
            0.6477,
            0.0939,
            1.1168,
            0.0453,
            0.0423,
            0.0371,
            1.4178,
            0.1112,
            0.1178,
            0.1112
        ],
        "SNB": 5.4084
    }
}
```
